import{c as K,a as c,f,s as g}from"./DGFX4iM9.js";import{I as L,s as O}from"./Bk-NhEkZ.js";import{f as Q,p as I,t as b,x as k,q as N,z as S,c as r,r as s,w as m}from"./BzWkDI0A.js";import{l as T,s as U,p as R,i as h}from"./DIWfqQCs.js";import{c as W}from"./DYJxVhev.js";import{a as y,s as E,c as X}from"./D6jj0-RU.js";function ct(x,t){const l=T(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18"}]];L(x,U({name:"server"},()=>l,{get iconNode(){return n},children:(u,v)=>{var d=K(),_=Q(d);O(_,t,"default",{},null),c(u,d)},$$slots:{default:!0}}))}var Y=f('<span role="img"></span>');function Z(x,t){I(t,!0);let l=R(t,"size",3,"sm");const n=new Set(["running","active","success","ok"]),u=new Set(["stopped","failure","error","failed"]),v=new Set(["not_configured","unknown","warning","starting","stopping"]),d=S(()=>n.has(t.status)?"bg-emerald-500":u.has(t.status)?"bg-red-500":v.has(t.status)?"bg-amber-400":"bg-slate-400"),_=S(()=>l()==="md"?"w-3 h-3":"w-2.5 h-2.5");var o=Y();b(()=>{y(o,1,`inline-block rounded-full flex-shrink-0 ${k(d)??""} ${k(_)??""}`),E(o,"aria-label",`${t.status??""} status`),E(o,"title",t.status)}),c(x,o),N()}var $=f('<p class="mt-1 text-sm"><span> </span></p>'),tt=f('<p class="mt-1 text-sm text-muted-foreground"> </p>'),et=f('<p class="mt-1 text-xs text-muted-foreground"> </p>'),at=f('<div class="flex-shrink-0 ml-4"><div class="w-12 h-12 rounded-full bg-muted flex items-center justify-center"><!></div></div>'),rt=f('<article aria-live="polite"><div class="flex items-center justify-between"><div class="flex-1 min-w-0"><p class="text-sm font-semibold text-muted-foreground uppercase tracking-wide"> </p> <div class="mt-1 flex items-center gap-2"><p> </p> <!></div> <!> <!> <!></div> <!></div></article>');function ut(x,t){I(t,!0);let l=R(t,"unavailable",3,!1);var n=rt(),u=r(n),v=r(u),d=r(v),_=r(d,!0);s(d);var o=m(d,2),w=r(o),j=r(w,!0);s(w);var D=m(w,2);{var V=e=>{Z(e,{get status(){return t.statusValue},size:"md"})};h(D,e=>{t.statusValue&&e(V)})}s(o);var z=m(o,2);{var q=e=>{var a=$(),i=r(a),p=r(i);s(i),s(a),b(()=>{y(i,1,X(t.trend.direction==="up"?"text-emerald-600":"text-red-600")),g(p,`${t.trend.direction==="up"?"↑":"↓"} ${t.trend.value??""}`)}),c(e,a)};h(z,e=>{t.trend&&e(q)})}var C=m(z,2);{var A=e=>{var a=tt(),i=r(a,!0);s(a),b(()=>g(i,t.subtitle)),c(e,a)};h(C,e=>{t.subtitle&&e(A)})}var B=m(C,2);{var G=e=>{var a=et(),i=r(a,!0);s(a),b(()=>g(i,t.hint)),c(e,a)};h(B,e=>{t.hint&&l()&&e(G)})}s(v);var M=m(v,2);{var P=e=>{const a=S(()=>t.icon);var i=at(),p=r(i),F=r(p);W(F,()=>k(a),(H,J)=>{J(H,{class:"w-6 h-6 text-muted-foreground"})}),s(p),s(i),c(e,i)};h(M,e=>{t.icon&&e(P)})}s(u),s(n),b(()=>{y(n,1,`bg-card rounded-lg shadow-sm p-6 ${l()?"bg-muted/50 border border-dashed border-border":""}`),g(_,t.title),y(w,1,`text-2xl font-bold ${l()?"text-muted-foreground":"text-card-foreground"} truncate`),g(j,t.value)}),c(x,n),N()}export{ut as C,ct as S};
