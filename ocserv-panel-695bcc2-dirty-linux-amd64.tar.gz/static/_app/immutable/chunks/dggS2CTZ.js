function i(t,c,o){const a=Math.max(1,o),e=Math.max(1,Math.ceil(t.length/a)),n=Math.min(Math.max(1,c),e),s=(n-1)*a,g=s+a;return{items:t.slice(s,g),totalPages:e,page:n,pageSize:a}}export{i as p};
