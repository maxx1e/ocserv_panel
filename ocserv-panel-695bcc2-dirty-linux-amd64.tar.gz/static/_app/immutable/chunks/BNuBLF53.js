import{a as s}from"./DP-70iWd.js";import{c as B,a as p,s as P,f as y,d as T,g as U}from"./DGFX4iM9.js";import{f as j,c as n,r as a,w as i,t as I,p as D,x as S,q as M,z as k,af as q}from"./BzWkDI0A.js";import{s as O}from"./dDwa59f_.js";import{l as A,s as E,i as R}from"./DIWfqQCs.js";import{I as F,s as G}from"./Bk-NhEkZ.js";function ne(){return s("/api/ocserv/sessions")}function ae(t){return s("/api/ocserv/sessions/disconnect",{method:"POST",body:{sessionId:t}})}function se(t){return s(`/api/ocserv/sessions/${encodeURIComponent(t)}`)}function oe(t){return s("/api/ocserv/sessions/terminate",{method:"POST",body:{sessionId:t}})}function re(){return s("/api/ocserv/readiness")}function ie(){return s("/api/ocserv/server/status")}function de(){return s("/api/ocserv/users/connected")}function ce(t){return s(`/api/ocserv/users/${encodeURIComponent(t)}/connections`)}function le(t){return s(`/api/ocserv/connections/${t}`)}function ve(){return s("/api/ocserv/events")}function ue(){return s("/api/ocserv/routes")}function be(){return s("/api/ocserv/bans")}function me(){return s("/api/ocserv/bans/points")}function fe(t){return s(`/api/ocserv/users/${encodeURIComponent(t)}/disconnect`,{method:"POST"})}function ge(t){return s(`/api/ocserv/bans/${encodeURIComponent(t)}/unban`,{method:"POST"})}function H(t,e){const o=A(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const d=[["path",{d:"m2 2 20 20"}],["path",{d:"M5 5a1 1 0 0 0-1 1v7c0 5 3.5 7.5 7.67 8.94a1 1 0 0 0 .67.01c2.35-.82 4.48-1.97 5.9-3.71"}],["path",{d:"M9.309 3.652A12.252 12.252 0 0 0 11.24 2.28a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1v7a9.784 9.784 0 0 1-.08 1.264"}]];F(t,E({name:"shield-off"},()=>o,{get iconNode(){return d},children:(r,l)=>{var v=B(),m=j(v);G(m,e,"default",{},null),p(r,v)},$$slots:{default:!0}}))}var J=y("<div><!></div>"),K=y('<div class="bg-white rounded-lg shadow-sm"><div class="flex items-center justify-between px-6 py-4 border-b border-slate-100"><h3 class="text-sm font-semibold text-slate-700"> </h3> <!></div> <div class="overflow-x-auto"><!></div></div>');function xe(t,e){var o=K(),d=n(o),r=n(d),l=n(r,!0);a(r);var v=i(r,2);{var m=u=>{var c=J(),x=n(c);O(x,()=>e.actions),a(c),p(u,c)};R(v,u=>{e.actions&&u(m)})}a(d);var g=i(d,2),f=n(g);O(f,()=>e.children),a(g),a(o),I(()=>P(l,e.title)),p(t,o)}var L=y('<div class="flex items-center justify-between px-6 py-3 border-t border-slate-100 bg-white rounded-b-lg"><button type="button" class="inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md border border-slate-200 text-slate-600 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">← Prev</button> <span class="text-sm text-slate-500"> </span> <button type="button" class="inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md border border-slate-200 text-slate-600 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">Next →</button></div>'),Q=y("<!> <!>",1);function he(t,e){D(e,!0);const o=k(()=>e.totalPages>1),d=k(()=>e.currentPage>1),r=k(()=>e.currentPage<e.totalPages);var l=Q(),v=j(l);O(v,()=>e.children);var m=i(v,2);{var g=f=>{var u=L(),c=n(u),x=i(c,2),w=n(x);a(x);var _=i(x,2);a(u),I(()=>{c.disabled=!S(d),P(w,`Page ${e.currentPage??""} of ${e.totalPages??""}`),_.disabled=!S(r)}),U("click",c,()=>e.onPageChange(e.currentPage-1)),U("click",_,()=>e.onPageChange(e.currentPage+1)),p(f,u)};R(m,f=>{S(o)&&f(g)})}p(t,l),M()}T(["click"]);var V=y('<div class="mt-3 px-3 py-2 bg-red-50 rounded text-sm text-red-700" role="alert"> </div>'),W=y('<div class="fixed inset-0 bg-black/50 flex items-center justify-center z-50" role="dialog" aria-modal="true" aria-labelledby="unban-ip-title"><div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6"><div class="flex items-start gap-3"><div class="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center"><!></div> <div class="flex-1"><h2 id="unban-ip-title" class="text-lg font-semibold text-slate-800">Unban IP address?</h2> <p class="text-sm text-slate-600 mt-2">Remove <strong class="font-mono"> </strong> from the ban list. The IP will be allowed to attempt connections again.</p></div></div> <!> <div class="flex items-center justify-end gap-3 mt-6"><button type="button" class="px-4 py-2 text-sm font-medium rounded-md border border-slate-200 text-slate-600 bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">Cancel</button> <button type="button" class="px-4 py-2 text-sm font-medium rounded-md bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"> </button></div></div></div>');function pe(t,e){var o=W(),d=n(o),r=n(d),l=n(r),v=n(l);H(v,{class:"w-5 h-5 text-blue-600"}),a(l);var m=i(l,2),g=i(n(m),2),f=i(n(g)),u=n(f,!0);a(f),q(),a(g),a(m),a(r);var c=i(r,2);{var x=h=>{var b=V(),z=n(b,!0);a(b),I(()=>P(z,e.error)),p(h,b)};R(c,h=>{e.error&&h(x)})}var w=i(c,2),_=n(w),C=i(_,2),N=n(C,!0);a(C),a(w),a(d),a(o),I(()=>{P(u,e.ip),_.disabled=e.submitting,C.disabled=e.submitting,P(N,e.submitting?"Unbanning...":"Unban IP")}),U("click",_,function(...h){var b;(b=e.onCancel)==null||b.apply(this,h)}),U("click",C,function(...h){var b;(b=e.onConfirm)==null||b.apply(this,h)}),p(t,o)}T(["click"]);export{xe as C,he as P,pe as U,ce as a,ne as b,se as c,ve as d,ue as e,le as f,de as g,be as h,me as i,re as j,ie as k,ae as l,fe as m,oe as t,ge as u};
