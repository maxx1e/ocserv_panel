import{c as U,a as d,f as p,d as ye,g as W,s as B,e as Oe}from"../chunks/DGFX4iM9.js";import{o as Le}from"../chunks/DLnnqEdn.js";import{U as Ke,A as De,bg as Fe,b3 as Ue,h as ge,C as Ve,i as we,G as Me,s as Se,e as We,g as Ge,p as ne,f as M,q as se,t as F,w as h,aj as J,x as s,z as T,c as f,af as he,r as u,bh as ze,bi as Ee,v as Q,y as fe,ae as Je,a0 as Be,n as Qe,bj as Xe}from"../chunks/BzWkDI0A.js";import{i as I,p as L,l as X,s as Y}from"../chunks/DIWfqQCs.js";import{s as ke}from"../chunks/dDwa59f_.js";import{a as Ye,d as Ze,s as qe,b as et,t as tt}from"../chunks/4F4iStA-.js";import{m as de,t as ue,a as Ce,l as Ne,b as $e,e as me,s as Pe,d as xe,f as at,g as Te,i as rt}from"../chunks/BDKPvEjd.js";import{s as le,a as ve,e as pe,i as be}from"../chunks/D6jj0-RU.js";import{h as ot}from"../chunks/CZcae9df.js";import{g as nt,b as st,p as it,c as lt}from"../chunks/pc55qxiq.js";import{b as ct}from"../chunks/B21uzqZT.js";import{I as Z,s as ee,i as dt}from"../chunks/Bk-NhEkZ.js";import{U as ut}from"../chunks/DrgqLczF.js";import{H as mt}from"../chunks/RmdxD5nT.js";import{S as vt}from"../chunks/5cs0dc4C.js";import{S as ft}from"../chunks/BoatdSNy.js";import{F as gt}from"../chunks/c1Exx641.js";import{c as _e}from"../chunks/DYJxVhev.js";import{s as ht}from"../chunks/Bol2GKNy.js";import{S as pt}from"../chunks/B0tZ80K3.js";import{b as bt}from"../chunks/Da4U0hdn.js";function je(o,e){let r=null,i=ge;var c;if(ge){r=We;for(var a=Ge(document.head);a!==null&&(a.nodeType!==Ve||a.data!==o);)a=we(a);if(a===null)Me(!1);else{var t=we(a);a.remove(),Se(t)}}ge||(c=document.head.appendChild(Ke()));try{De(()=>e(c),Fe|Ue)}finally{i&&(Me(!0),Se(r))}}const _t=!0,xt=!1,Ia=Object.freeze(Object.defineProperty({__proto__:null,prerender:_t,ssr:xt},Symbol.toStringTag,{value:"Module"}));var yt=p('<meta name="theme-color"/>');function wt(o,e){ne(e,!0);var r=U(),i=M(r);{var c=a=>{var t=yt();F(()=>le(t,"content",e.themeColors.dark)),d(a,t)};I(i,a=>{e.themeColors&&a(c)})}d(o,r),se()}var Mt=p('<meta name="theme-color"/>'),St=p("<!> <!>",1);function kt(o,e){ne(e,!0);let r=L(e,"trueNonce",3,"");je("lbftxs",i=>{var c=St(),a=M(c);{var t=S=>{var k=Mt();F(()=>le(k,"content",e.themeColors.dark)),d(S,k)};I(a,S=>{e.themeColors&&S(t)})}var l=h(a,2);ot(l,()=>`<script${r()?` nonce=${r()}`:""}>(`+Ye.toString()+")("+JSON.stringify(e.initConfig)+");<\/script>"),d(i,c)}),se()}function Ct(o,e){ne(e,!0);let r=L(e,"track",3,!0),i=L(e,"defaultMode",3,"system"),c=L(e,"disableTransitions",3,!0),a=L(e,"darkClassNames",19,()=>["dark"]),t=L(e,"lightClassNames",19,()=>[]),l=L(e,"defaultTheme",3,""),S=L(e,"nonce",3,""),k=L(e,"themeStorageKey",3,"mode-watcher-theme"),q=L(e,"modeStorageKey",3,"mode-watcher-mode"),A=L(e,"disableHeadScriptInjection",3,!1),V=L(e,"synchronousModeChanges",3,!1);de.current=q(),ue.current=k(),Ce.current=a(),Ne.current=t(),$e.current=c(),me.current=e.themeColors,Pe.current=V(),J(()=>{Pe.current=V()}),J(()=>{$e.current=c()}),J(()=>{me.current=e.themeColors}),J(()=>{Ce.current=a()}),J(()=>{Ne.current=t()}),J(()=>{de.current=q()}),J(()=>{ue.current=k()}),J(()=>{xe.current,de.current,ue.current,at.current}),Le(()=>{Te.tracking(r()),Te.query();const g=localStorage.getItem(de.current);qe(rt(g)?g:i());const z=localStorage.getItem(ue.current);et(z||l())});const H=Ze({defaultMode:i(),themeColors:e.themeColors,darkClassNames:a(),lightClassNames:t(),defaultTheme:l(),modeStorageKey:q(),themeStorageKey:k()}),R=T(()=>typeof window>"u"?S():"");var j=U(),O=M(j);{var m=g=>{wt(g,{get themeColors(){return me.current}})},v=g=>{kt(g,{get trueNonce(){return s(R)},get initConfig(){return H},get themeColors(){return me.current}})};I(O,g=>{A()?g(m):g(v,-1)})}d(o,j),se()}function Nt(){return{setupRequired:null,principal:null,loading:!0,error:""}}function $t(o,e){o.principal=it(e)}async function Pt(o){o.loading=!0,o.error="";try{const e=await nt();if(o.setupRequired=e.required,e.required){o.principal=null;return}try{$t(o,await st())}catch(r){o.principal=null,r instanceof Error&&!r.message.includes("Sign in is required")&&(o.error=r.message)}}catch(e){o.error=e instanceof Error?e.message:"Unable to reach the backend API."}finally{o.loading=!1}}function Tt(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"}],["path",{d:"M12 11h4"}],["path",{d:"M12 16h4"}],["path",{d:"M8 11h.01"}],["path",{d:"M8 16h.01"}]];Z(o,Y({name:"clipboard-list"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function It(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1"}]];Z(o,Y({name:"layout-dashboard"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function Lt(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"}]];Z(o,Y({name:"link"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function zt(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["path",{d:"m16 17 5-5-5-5"}],["path",{d:"M21 12H9"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"}]];Z(o,Y({name:"log-out"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function Et(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["path",{d:"M4 5h16"}],["path",{d:"M4 12h16"}],["path",{d:"M4 19h16"}]];Z(o,Y({name:"menu"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function qt(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"}]];Z(o,Y({name:"moon"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function jt(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["circle",{cx:"12",cy:"12",r:"4"}],["path",{d:"M12 2v2"}],["path",{d:"M12 20v2"}],["path",{d:"m4.93 4.93 1.41 1.41"}],["path",{d:"m17.66 17.66 1.41 1.41"}],["path",{d:"M2 12h2"}],["path",{d:"M20 12h2"}],["path",{d:"m6.34 17.66-1.41 1.41"}],["path",{d:"m19.07 4.93-1.41 1.41"}]];Z(o,Y({name:"sun"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}function At(o,e){const r=X(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const i=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"}],["circle",{cx:"12",cy:"7",r:"4"}]];Z(o,Y({name:"user"},()=>r,{get iconNode(){return i},children:(c,a)=>{var t=U(),l=M(t);ee(l,e,"default",{},null),d(c,t)},$$slots:{default:!0}}))}const Ie=["owner","viewer","read_only","read-only"],Ht=[{href:"/",label:"Dashboard",description:"Local ocserv status overview",icon:It,section:"main",roles:Ie},{href:"/users",label:"Users",description:"Password and certificate users",icon:ut,section:"main",roles:["owner"]},{href:"/sessions",label:"Sessions",description:"Active session visibility and control",icon:Lt,section:"main",roles:["owner"]},{href:"/history",label:"History",description:"Historical session analytics",icon:mt,section:"main",roles:Ie},{href:"/config",label:"Config",description:"Validated configuration editing",icon:vt,section:"management",roles:["owner"]},{href:"/certificates",label:"Certificates",description:"Certificate visibility and lifecycle",icon:ft,section:"management",roles:["owner"]},{href:"/audit",label:"Audit",description:"Administrative action history",icon:gt,section:"management",roles:["owner"]},{href:"/settings",label:"Settings",description:"Local panel settings",icon:Tt,section:"system",roles:["owner"]}],Rt=()=>{const o=ht;return{page:{subscribe:o.page.subscribe},navigating:{subscribe:o.navigating.subscribe},updated:o.updated}},Ae={subscribe(o){return Rt().page.subscribe(o)}};var Ot=p('<button type="button" class="fixed inset-0 bg-black/50 z-20 md:hidden cursor-default" aria-label="Close navigation menu"></button>'),Kt=p("<li><a><!> </a></li>"),Dt=p('<p class="px-3 text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 mt-2">Main</p> <ul class="space-y-1"></ul>',1),Ft=p("<li><a><!> </a></li>"),Ut=p('<p class="px-3 text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 mt-4">Management</p> <ul class="space-y-1"></ul>',1),Vt=p("<li><a><!> </a></li>"),Wt=p('<p class="px-3 text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 mt-4">System</p> <ul class="space-y-1"></ul>',1),Gt=p('<p class="px-3 py-2 text-sm text-slate-400">Checking session...</p>'),Jt=p('<a href="/setup" class="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-slate-400 hover:bg-slate-600/20 hover:text-slate-200 transition-colors">Setup owner</a>'),Bt=p('<div class="border-t border-slate-600 px-6 py-4"><p class="text-xs text-slate-400">Signed in as</p> <p class="text-sm font-medium text-slate-200"> </p> <p class="text-xs text-slate-400"> </p> <button type="button" class="mt-2 flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 transition-colors"><!> Logout</button></div>'),Qt=p('<div class="px-6 py-2 text-sm text-red-400"> </div>'),Xt=p('<!> <aside><div class="px-6 py-5"><div class="flex items-center gap-2"><!> <h1 class="text-lg font-bold text-white tracking-tight">ocserv Panel</h1></div> <p class="text-xs text-slate-400 mt-1">Single-node local administration</p></div> <nav class="flex-1 overflow-y-auto px-3" aria-label="Primary navigation"><!> <!> <!> <!></nav> <!> <!></aside>',1);function Yt(o,e){ne(e,!0);const r=()=>Ee(Ae,"$page",i),[i,c]=ze();let a=L(e,"mobileOpen",3,!1);const t=T(()=>e.navItems.filter(n=>n.section==="main")),l=T(()=>e.navItems.filter(n=>n.section==="management")),S=T(()=>e.navItems.filter(n=>n.section==="system"));function k(n){return n==="/"?r().url.pathname==="/":r().url.pathname.startsWith(n)}var q=Xt(),A=M(q);{var V=n=>{var b=Ot();W("click",b,function(...w){var D;(D=e.onCloseMobile)==null||D.apply(this,w)}),d(n,b)};I(A,n=>{a()&&n(V)})}var H=h(A,2),R=f(H),j=f(R),O=f(j);pt(O,{class:"w-6 h-6 text-slate-200"}),he(2),u(j),he(2),u(R);var m=h(R,2),v=f(m);{var g=n=>{var b=Dt(),w=h(M(b),2);pe(w,21,()=>s(t),be,(D,x)=>{const oe=T(()=>s(x).icon);var N=Kt(),_=f(N),E=f(_);_e(E,()=>s(oe),(y,P)=>{P(y,{class:"w-4 h-4"})});var G=h(E);u(_),u(N),F(y=>{le(_,"href",s(x).href),ve(_,1,`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${y??""}`),B(G,` ${s(x).label??""}`)},[()=>k(s(x).href)?"bg-slate-600/30 text-slate-200":"text-slate-400 hover:bg-slate-600/20 hover:text-slate-200"]),W("click",_,function(...y){var P;(P=e.onCloseMobile)==null||P.apply(this,y)}),d(D,N)}),u(w),d(n,b)};I(v,n=>{s(t).length>0&&n(g)})}var z=h(v,2);{var ie=n=>{var b=Ut(),w=h(M(b),2);pe(w,21,()=>s(l),be,(D,x)=>{const oe=T(()=>s(x).icon);var N=Ft(),_=f(N),E=f(_);_e(E,()=>s(oe),(y,P)=>{P(y,{class:"w-4 h-4"})});var G=h(E);u(_),u(N),F(y=>{le(_,"href",s(x).href),ve(_,1,`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${y??""}`),B(G,` ${s(x).label??""}`)},[()=>k(s(x).href)?"bg-slate-600/30 text-slate-200":"text-slate-400 hover:bg-slate-600/20 hover:text-slate-200"]),W("click",_,function(...y){var P;(P=e.onCloseMobile)==null||P.apply(this,y)}),d(D,N)}),u(w),d(n,b)};I(z,n=>{s(l).length>0&&n(ie)})}var te=h(z,2);{var C=n=>{var b=Wt(),w=h(M(b),2);pe(w,21,()=>s(S),be,(D,x)=>{const oe=T(()=>s(x).icon);var N=Vt(),_=f(N),E=f(_);_e(E,()=>s(oe),(y,P)=>{P(y,{class:"w-4 h-4"})});var G=h(E);u(_),u(N),F(y=>{le(_,"href",s(x).href),ve(_,1,`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${y??""}`),B(G,` ${s(x).label??""}`)},[()=>k(s(x).href)?"bg-slate-600/30 text-slate-200":"text-slate-400 hover:bg-slate-600/20 hover:text-slate-200"]),W("click",_,function(...y){var P;(P=e.onCloseMobile)==null||P.apply(this,y)}),d(D,N)}),u(w),d(n,b)};I(te,n=>{s(S).length>0&&n(C)})}var $=h(te,2);{var K=n=>{var b=Gt();d(n,b)},ce=n=>{var b=Jt();d(n,b)};I($,n=>{e.loading?n(K):e.setupRequired&&n(ce,1)})}u(m);var ae=h(m,2);{var re=n=>{var b=Bt(),w=h(f(b),2),D=f(w,!0);u(w);var x=h(w,2),oe=f(x,!0);u(x);var N=h(x,2),_=f(N);zt(_,{class:"w-4 h-4"}),he(),u(N),u(b),F(E=>{B(D,e.username),B(oe,E)},[()=>e.roles.join(", ")]),W("click",N,function(...E){var G;(G=e.onLogout)==null||G.apply(this,E)}),d(n,b)};I(ae,n=>{e.username&&n(re)})}var He=h(ae,2);{var Re=n=>{var b=Qt(),w=f(b,!0);u(b),F(()=>B(w,e.error)),d(n,b)};I(He,n=>{e.error&&n(Re)})}u(H),F(()=>ve(H,1,`fixed top-0 left-0 bottom-0 w-64 bg-slate-700 text-slate-300 flex-col z-30 ${a()?"flex":"hidden md:flex"}`)),d(o,q),se(),c()}ye(["click"]);var Zt=p('<button type="button" class="inline-flex items-center justify-center rounded-md p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"><!></button>');function ea(o,e){ne(e,!1),dt();var r=Zt(),i=f(r);{var c=t=>{jt(t,{class:"h-5 w-5"})},a=t=>{qt(t,{class:"h-5 w-5"})};I(i,t=>{xe.current==="dark"?t(c):t(a,-1)})}u(r),F(()=>le(r,"aria-label",xe.current==="dark"?"Switch to light mode":"Switch to dark mode")),W("click",r,function(...t){var l;(l=tt)==null||l.apply(this,t)}),d(o,r),se()}ye(["click"]);var ta=p('<button type="button" class="md:hidden p-2 -ml-2 text-muted-foreground hover:text-foreground transition-colors" aria-label="Toggle navigation menu"><!></button>'),aa=p('<div class="absolute right-0 mt-2 w-48 bg-card rounded-lg shadow-lg border border-border py-1 z-50"><button type="button" class="w-full text-left px-4 py-2 text-sm text-card-foreground hover:bg-muted">Sign out</button></div>'),ra=p('<header class="h-16 bg-card border-b border-border flex items-center justify-between px-6 sticky top-0 z-20"><div class="flex items-center gap-3"><!> <h2 class="text-lg font-semibold text-foreground"> </h2></div> <div class="flex items-center gap-2"><!> <div class="relative"><button type="button" class="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"><div class="w-8 h-8 rounded-full bg-muted flex items-center justify-center"><!></div> <span class="hidden md:inline"> </span></button> <!></div></div></header>');function oa(o,e){ne(e,!0);let r=fe(!1),i=fe(void 0);function c(){Q(r,!s(r))}function a(){Q(r,!1),e.onLogout()}function t(C){s(r)&&s(i)&&!s(i).contains(C.target)&&Q(r,!1)}var l=ra();Oe("click",Je,t);var S=f(l),k=f(S);{var q=C=>{var $=ta(),K=f($);Et(K,{class:"w-5 h-5"}),u($),W("click",$,function(...ce){var ae;(ae=e.onToggleSidebar)==null||ae.apply(this,ce)}),d(C,$)};I(k,C=>{e.onToggleSidebar&&C(q)})}var A=h(k,2),V=f(A,!0);u(A),u(S);var H=h(S,2),R=f(H);ea(R,{});var j=h(R,2),O=f(j),m=f(O),v=f(m);At(v,{class:"w-4 h-4 text-muted-foreground"}),u(m);var g=h(m,2),z=f(g,!0);u(g),u(O);var ie=h(O,2);{var te=C=>{var $=aa(),K=f($);u($),W("click",K,a),d(C,$)};I(ie,C=>{s(r)&&C(te)})}u(j),bt(j,C=>Q(i,C),()=>s(i)),u(H),u(l),F(()=>{B(V,e.title),B(z,e.username)}),W("click",O,c),d(o,l),se()}ye(["click"]);var na=p('<meta name="description" content="Local-first web administration panel for a single ocserv server"/>'),sa=p('<div class="min-h-screen bg-background flex items-center justify-center"><div class="text-muted-foreground text-sm">Loading...</div></div>'),ia=p('<div class="min-h-screen bg-background text-foreground"><!></div>'),la=p('<div class="min-h-screen bg-background text-foreground"><!> <div class="md:ml-64"><!> <main class="p-6"><!></main></div></div>'),ca=p("<!> <!>",1);function La(o,e){ne(e,!0);const r=()=>Ee(Ae,"$page",i),[i,c]=ze();let a=Be(Nt()),t=fe(""),l=fe(!1);const S=T(()=>a.principal?Ht.filter(m=>!m.roles||m.roles.some(v=>{var g,z;return(z=(g=a.principal)==null?void 0:g.roles)==null?void 0:z.includes(v)})):[]),k=T(()=>{var m;return a.setupRequired?"Setup":a.principal?((m=s(S).find(v=>v.href===r().url.pathname||v.href!=="/"&&r().url.pathname.startsWith(v.href)))==null?void 0:m.label)??"Dashboard":"Login"});Le(async()=>{if(await Pt(a),a.principal)try{const v=(await ct()).sections.flatMap(g=>g.settings).find(g=>g.key==="general.theme");v&&(v.value==="light"||v.value==="dark"||v.value==="system")&&qe(v.value)}catch{}});async function q(){Q(t,"");try{await lt(),a.principal=null,window.location.href="/login"}catch(m){Q(t,m instanceof Error?m.message:"Logout failed.",!0)}}var A=ca();je("12qhfyh",m=>{var v=na();Qe(()=>{Xe.title="ocserv Panel"}),d(m,v)});var V=M(A);Ct(V,{});var H=h(V,2);{var R=m=>{var v=sa();d(m,v)},j=m=>{var v=ia(),g=f(v);ke(g,()=>e.children),u(v),d(m,v)},O=m=>{var v=la(),g=f(v);{let $=T(()=>{var re;return((re=a.principal)==null?void 0:re.username)??""}),K=T(()=>{var re;return((re=a.principal)==null?void 0:re.roles)??[]}),ce=T(()=>a.setupRequired??!1),ae=T(()=>a.error||s(t));Yt(g,{get navItems(){return s(S)},get username(){return s($)},get roles(){return s(K)},onLogout:q,get loading(){return a.loading},get setupRequired(){return s(ce)},get error(){return s(ae)},get mobileOpen(){return s(l)},onCloseMobile:()=>Q(l,!1)})}var z=h(g,2),ie=f(z);{let $=T(()=>{var K;return((K=a.principal)==null?void 0:K.username)??""});oa(ie,{get title(){return s(k)},get username(){return s($)},onLogout:q,onToggleSidebar:()=>Q(l,!s(l))})}var te=h(ie,2),C=f(te);ke(C,()=>e.children),u(te),u(z),u(v),d(m,v)};I(H,m=>{a.loading?m(R):a.setupRequired||!a.principal?m(j,1):m(O,-1)})}d(o,A),se(),c()}export{La as component,Ia as universal};
