import{l as o,a as r}from"../chunks/Bol2GKNy.js";export{o as load_css,r as start};
